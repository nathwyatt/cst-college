
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import  javax.servlet.http.HttpSession;

/**
 *
 * @author UR SYSTEM ADMIN
 */
@WebServlet(urlPatterns = {"/login"})
public class login extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("text/html;charset=UTF-8");
        try
        {
          Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/cstcollege","root","");
            //create statement object
            String email=request.getParameter("email");
            String pass=request.getParameter("password");
            String q="select* from tbladmin";
            Statement st=con.createStatement();
            ResultSet s=st.executeQuery(q);
            while(s.next())
            {
                if(email.equals(s.getString("email")) && pass.equals(s.getString("password")))
                {
                        out.print("Welcome, "+email); 
                    HttpSession session=request.getSession();
                    session.setAttribute("email",email); 
                    response.sendRedirect("admin_dash.jsp");
                }
                else
                {
                    out.print("Sorry, username or password error!"); 
                   response.sendRedirect("admin-login.jsp");
                }
            }
        }
        catch(Exception e)
        {
           out.print(e);
        }
    }
}

    